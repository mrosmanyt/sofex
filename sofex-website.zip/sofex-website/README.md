# Sofex Soap & Chemical Industries — Website

Official company website for **Sofex Soap & Chemical Industries**, a
SECP-registered Pakistani manufacturer of dishwashing liquid, detergents,
soaps, shampoos and surface cleaners.

## What's in this repo

- `index.html` — the entire website (single self-contained file: HTML, CSS
  and JavaScript all inline, no build step, no external dependencies except
  Google Fonts). Includes:
  - Company hero, credentials and flagship product section
  - A full 36-SKU product catalogue with search and category filters
  - A distributor sign-up / login portal with wholesale pricing tiers
  - Cursor-editor-inspired UI with full light/dark theme support
- `img/` — product photography used on the site (flagship Lemon Fresh
  Dishwashing Liquid: hero shot, three-angle catalogue shot, kitchen
  lifestyle shot)

## Running it locally

No build tools or dependencies are required. From this folder, run either:

```bash
python -m http.server 8000
```

or, if you have Node.js:

```bash
npx serve -l 8000
```

Then open `http://localhost:8000` in your browser.

You can also just double-click `index.html` to open it directly in a
browser — everything works from `file://` too.

## Notes

- The distributor portal's "backend" is entirely client-side (`localStorage`)
  with PBKDF2-hashed passwords/activation codes — there is no real server.
  Order and distributor-application submissions go out via WhatsApp deep
  links. This is intentional for a low-cost static site; a real backend can
  replace the `localStorage` layer later without touching the UI.
- Prices, product list and contact details are current as of September 2026
  and should be kept up to date directly in `index.html`.

## Deploying

Since this is a static site, it can be hosted for free on **GitHub Pages**:

1. Push this repo to GitHub.
2. Go to **Settings → Pages**.
3. Under "Build and deployment", set **Source** to `Deploy from a branch`,
   branch `main`, folder `/ (root)`.
4. Save — the site will be live at
   `https://<your-username>.github.io/<repo-name>/` within a minute or two.

---

© 2026 Sofex Soap & Chemical Industries. Registered with SECP, Pakistan.
